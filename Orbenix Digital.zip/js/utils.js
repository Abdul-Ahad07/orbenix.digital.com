export function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[c]);
}

export function safeUrl(value = "") {
  try {
    const u = new URL(value);
    return ["http:", "https:"].includes(u.protocol) ? u.href : "";
  } catch { return ""; }
}

export function createId(prefix = "c") {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function debounce(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export function showToast(message, { undo, timeout = 2600 } = {}) {
  const toast = document.getElementById("toast");
  if(!toast) return;
  toast.innerHTML = "";
  const span = document.createElement("span");
  span.textContent = message;
  toast.appendChild(span);
  if (undo) {
    const btn = document.createElement("button");
    btn.textContent = "Undo";
    btn.onclick = () => { undo(); toast.classList.remove("show"); };
    toast.appendChild(btn);
  }
  toast.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toast.classList.remove("show"), timeout);
}

export function downloadBlob(content, filename, type = "application/json") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function toCsv(rows) {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const escape = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [
    headers.map(escape).join(","),
    ...rows.map(r => headers.map(h => escape(r[h])).join(","))
  ].join("\n");
}

export function cleanWaNumber(num = "") {
  let clean = String(num).replace(/\D/g, '');
  if (clean.startsWith('0')) clean = '92' + clean.slice(1);
  return clean;
}

export function getWaLink(num = "", text = "") {
  const c = cleanWaNumber(num);
  if (!c) return "";
  return `https://wa.me/${c}${text ? '?text=' + encodeURIComponent(text) : ''}`;
}